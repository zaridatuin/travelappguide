package com.example.travelguideapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import com.example.travelguideapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDestinations.setOnClickListener {
            startActivity(Intent(this, DestinationsActivity::class.java))
        }

        binding.btnTips.setOnClickListener {
            startActivity(Intent(this, TravelTipsActivity::class.java))
        }

        binding.btnContact.setOnClickListener {
            startActivity(Intent(this, ContactUsActivity::class.java))
        }
    }
}