package com.example.travelguideapp


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.travelguideapp.databinding.ActivityTravelTipsBinding

class TravelTipsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTravelTipsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTravelTipsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}