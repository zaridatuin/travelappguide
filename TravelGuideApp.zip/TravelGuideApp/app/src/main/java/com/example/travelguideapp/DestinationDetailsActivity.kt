package com.example.travelguideapp


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.travelguideapp.databinding.ActivityDestinationDetailsBinding

class DestinationDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDestinationDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDestinationDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = intent.getStringExtra("destinationName")
        val imageResId = intent.getIntExtra("destinationImage", 0)

        binding.textViewDestinationName.text = name
        binding.imageViewDestination.setImageResource(imageResId)
    }
}