package com.example.travelguideapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.BaseAdapter
import com.example.travelguideapp.models.Destination
import com.example.travelguideapp.R

class DestinationAdapter(private val context: Context, private val destinations: List<Destination>) : BaseAdapter() {
    override fun getCount(): Int = destinations.size

    override fun getItem(position: Int): Any = destinations[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_destination, parent, false)
        val destination = destinations[position]
        view.findViewById<ImageView>(R.id.imageView).setImageResource(destination.imageResId)
        view.findViewById<TextView>(R.id.textView).text = destination.name
        return view
    }
}