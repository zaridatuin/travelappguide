package com.example.travelguideapp


import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import androidx.appcompat.app.AppCompatActivity
import com.example.travelguideapp.adapters.DestinationAdapter
import com.example.travelguideapp.databinding.ActivityDestinationsBinding
import com.example.travelguideapp.models.Destination

class DestinationsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDestinationsBinding
    private lateinit var destinationAdapter: DestinationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDestinationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val destinations = listOf(
            Destination("Paris", R.drawable.paris),
            Destination("New York", R.drawable.new_york),
            Destination("Tokyo", R.drawable.tokyo),
            Destination("Sydney", R.drawable.sydney)
        )

        destinationAdapter = DestinationAdapter(this, destinations)
        binding.gridView.adapter = destinationAdapter

        binding.gridView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, DestinationDetailsActivity::class.java)
            intent.putExtra("destinationName", destinations[position].name)
            intent.putExtra("destinationImage", destinations[position].imageResId)
            startActivity(intent)
        }
    }
}