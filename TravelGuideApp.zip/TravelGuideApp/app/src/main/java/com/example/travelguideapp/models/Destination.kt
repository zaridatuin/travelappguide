package com.example.travelguideapp.models

data class Destination(val name: String, val imageResId: Int)